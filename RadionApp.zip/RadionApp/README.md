# Radion — Native Android App

Full build: real voice, real AI brain, real hologram viewer, real system access
(calendar, contacts, calls, alarms) — all in one native app.

## Before you build: add your API key

The AI brain needs your own Anthropic API key to work (get one free to start at
console.anthropic.com). Open:

  app/src/main/java/com/radion/assistant/AssistantBrain.kt

and replace this line near the top:

  private const val API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE"

with your real key. Without this, everything else works (voice, hologram,
calendar, permissions) except the AI chat replies.

## What's real here

- **Chat tab**: type or tap the mic to talk to RADION. Real speech-to-text,
  real Claude API calls with tool-calling, real text-to-speech replies.
- **Hologram**: say/type anything with the word "hologram" in it — a real
  interactive 3D wireframe renders inline (drag to rotate, pinch to zoom).
  Same shape library as the web version: planes, cars, rockets, planets,
  DNA, and more.
- **Web search**: the AI can search the live web for current information.
- **System tab**: request real Android permissions and use them —
  read your actual calendar, place a real phone call, open the real Clock
  app to set an alarm.

## How to build and run

1. Install Android Studio (free): https://developer.android.com/studio
2. Open this RadionApp folder in Android Studio ("Open", not "New Project")
3. Add your API key (see above)
4. Wait for Gradle sync to finish
5. Plug in your Android phone (USB debugging on), select it, hit Run ▶

## Building via GitHub Actions (no computer needed)

If you built the earlier version this way, the same build.yml workflow
works — just replace RadionApp.zip in your repo with this new version and
it'll rebuild automatically.
