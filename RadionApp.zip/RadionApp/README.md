# Radion — Native Android App

This is a real Android app project (Kotlin + Jetpack Compose), not a webpage.
It requests actual Android system permissions — calendar, contacts, phone calls,
microphone — and uses them for real, which is not possible in a browser-based app.

## What you need

- A **computer** (Windows, Mac, or Linux) — this cannot be built on a phone.
- **Android Studio**, free from https://developer.android.com/studio

## How to run it

1. Install Android Studio and open it.
2. Choose **Open** (not "New Project") and select this `RadionApp` folder.
3. Wait for it to finish "Gradle sync" — a progress bar at the bottom, can take
   a few minutes the first time.
4. Plug your Android phone into the computer via USB, with
   **Developer Options → USB Debugging** turned on (search "how to enable USB
   debugging" for your exact phone model if needed).
5. Your phone should appear in the device dropdown at the top of Android Studio.
6. Click the green **Run ▶** button.

The app installs and opens on your actual phone. Tapping "Request access" next
to Calendar, Contacts, etc. shows the real Android permission popup — the same
kind any app (Instagram, Gmail, etc.) shows you.

## What's real here vs. the web version (Radion the webpage)

- Calendar: reads and can create **real** events on your device calendar.
- Contacts: looks up **real** contacts.
- Phone calls: places a **real** call via the dialer.
- Alarms: opens your **real** system Clock app to confirm an alarm.

## What's not built yet

This project has the permission system and system-access functions working,
plus a basic screen to test them. It does **not** yet have:
- The voice/AI conversation loop (speech-to-text, Claude API calls, text-to-speech)
- A finished visual design matching the web version's HUD look

Those are the natural next steps once this base is confirmed running on your
phone.
