package com.radion.assistant

import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * The reasoning engine. Same architecture as the web version: send the conversation
 * plus a tool list to Claude, execute any tool calls it makes, feed results back,
 * repeat until it gives a final text answer.
 *
 * IMPORTANT: requires your own Anthropic API key below. This app runs outside
 * Claude's chat environment, so — same as the hosted web version — it needs real
 * credentials to reach the API. Get one at https://console.anthropic.com
 */
object AssistantBrain {

    // TODO: put your real API key here before this will work.
    private const val API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE"
    private const val API_URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-sonnet-4-6"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    private val systemPrompt = """
        You are RADION, a concise voice-first assistant running natively on the user's
        phone with real system access. Keep spoken replies short — 1-3 sentences unless
        detail is clearly wanted. Use the available tools for time, timers, notes,
        arithmetic, calendar, contacts, and web search instead of guessing. You have real
        web search — use it for anything current, recent, or that could have changed since
        your training. You do NOT have a hologram tool — holograms are triggered
        automatically outside of you whenever the user's message contains the word
        "hologram"; never attempt to invoke one yourself.
    """.trimIndent()

    private val tools = JSONArray().apply {
        put(JSONObject().apply {
            put("name", "get_time")
            put("description", "Get the current date and time.")
            put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
        })
        put(JSONObject().apply {
            put("name", "add_note")
            put("description", "Save a short note for the user.")
            put("input_schema", JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject().put("text", JSONObject().put("type", "string")))
                put("required", JSONArray().put("text"))
            })
        })
        put(JSONObject().apply {
            put("name", "calculate")
            put("description", "Evaluate a basic arithmetic expression.")
            put("input_schema", JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject().put("expression", JSONObject().put("type", "string")))
                put("required", JSONArray().put("expression"))
            })
        })
        put(JSONObject().apply {
            put("name", "get_upcoming_events")
            put("description", "Read the user's real upcoming calendar events.")
            put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
        })
        put(JSONObject().apply {
            put("name", "call_contact")
            put("description", "Place a real phone call to a contact by name.")
            put("input_schema", JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject().put("name", JSONObject().put("type", "string")))
                put("required", JSONArray().put("name"))
            })
        })
        put(JSONObject().apply {
            put("type", "web_search_20250305")
            put("name", "web_search")
        })
    }

    interface Callback {
        fun onResult(text: String)
        fun onError(message: String)
    }

    /**
     * Runs one full turn: sends history to the API, executes any tool calls locally
     * (via SystemTools for real system access, or the small local tools), loops until
     * a final text reply, then calls back on the main thread.
     */
    fun send(
        history: MutableList<JSONObject>,
        systemTools: SystemTools,
        mainHandler: android.os.Handler,
        callback: Callback
    ) {
        Thread {
            try {
                var guard = 0
                while (guard < 5) {
                    guard++
                    val body = JSONObject().apply {
                        put("model", MODEL)
                        put("max_tokens", 1000)
                        put("system", systemPrompt)
                        put("messages", JSONArray(history))
                        put("tools", tools)
                    }

                    val request = Request.Builder()
                        .url(API_URL)
                        .addHeader("x-api-key", API_KEY)
                        .addHeader("anthropic-version", "2023-06-01")
                        .addHeader("content-type", "application/json")
                        .post(body.toString().toRequestBody(JSON))
                        .build()

                    client.newCall(request).execute().use { response ->
                        val bodyStr = response.body?.string() ?: ""
                        if (!response.isSuccessful) {
                            mainHandler.post { callback.onError("API error ${response.code}: $bodyStr") }
                            return@Thread
                        }
                        val data = JSONObject(bodyStr)
                        val content = data.getJSONArray("content")
                        val toolUses = mutableListOf<JSONObject>()
                        var finalText = ""

                        for (i in 0 until content.length()) {
                            val block = content.getJSONObject(i)
                            when (block.getString("type")) {
                                "text" -> finalText += block.getString("text")
                                "tool_use" -> toolUses.add(block)
                            }
                        }

                        if (toolUses.isNotEmpty()) {
                            history.add(JSONObject().apply {
                                put("role", "assistant")
                                put("content", content)
                            })
                            val toolResults = JSONArray()
                            for (tu in toolUses) {
                                val name = tu.getString("name")
                                val input = tu.optJSONObject("input") ?: JSONObject()
                                val result = runTool(name, input, systemTools)
                                toolResults.put(JSONObject().apply {
                                    put("type", "tool_result")
                                    put("tool_use_id", tu.getString("id"))
                                    put("content", result)
                                })
                            }
                            history.add(JSONObject().apply {
                                put("role", "user")
                                put("content", toolResults)
                            })
                            continue // let the model respond to the tool results
                        }

                        history.add(JSONObject().apply {
                            put("role", "assistant")
                            put("content", finalText)
                        })
                        mainHandler.post { callback.onResult(finalText) }
                        return@Thread
                    }
                }
            } catch (e: IOException) {
                mainHandler.post { callback.onError("Connection issue: ${e.message}") }
            } catch (e: Exception) {
                mainHandler.post { callback.onError("Error: ${e.message}") }
            }
        }.start()
    }

    private fun runTool(name: String, input: JSONObject, systemTools: SystemTools): String {
        return when (name) {
            "get_time" -> java.text.DateFormat.getDateTimeInstance().format(java.util.Date())
            "add_note" -> { NotesStore.add(input.optString("text")); "Noted." }
            "calculate" -> calculateExpression(input.optString("expression"))
            "get_upcoming_events" -> {
                val events = systemTools.getUpcomingEvents()
                if (events.isEmpty()) "No upcoming events found." else events.joinToString(" | ")
            }
            "call_contact" -> {
                val number = systemTools.findContactNumber(input.optString("name"))
                if (number != null) { systemTools.callNumber(number); "Calling ${input.optString("name")}." }
                else "Couldn't find that contact."
            }
            else -> "Unknown tool."
        }
    }
}

/** Simple in-memory notes store, mirrors the web version's notes array. */
object NotesStore {
    private val notes = mutableListOf<String>()
    fun add(text: String) { notes.add(text) }
    fun all(): List<String> = notes
}

// javax.script doesn't exist on Android (desktop-Java-only), so basic arithmetic is
// evaluated with a small hand-written recursive-descent parser instead.
private fun calculateExpression(expr: String): String {
    return try {
        val clean = expr.replace(" ", "")
        if (!clean.matches(Regex("^[0-9+\\-*/().]+$"))) return "Could not evaluate that."
        val result = SimpleMathParser(clean).parse()
        if (result == result.toLong().toDouble()) result.toLong().toString() else result.toString()
    } catch (e: Exception) { "Could not evaluate that expression." }
}

private class SimpleMathParser(private val s: String) {
    private var pos = 0
    fun parse(): Double { val r = parseExpr(); return r }
    private fun peek(): Char? = if (pos < s.length) s[pos] else null
    private fun parseExpr(): Double {
        var v = parseTerm()
        while (peek() == '+' || peek() == '-') {
            val op = s[pos]; pos++
            val rhs = parseTerm()
            v = if (op == '+') v + rhs else v - rhs
        }
        return v
    }
    private fun parseTerm(): Double {
        var v = parseFactor()
        while (peek() == '*' || peek() == '/') {
            val op = s[pos]; pos++
            val rhs = parseFactor()
            v = if (op == '*') v * rhs else v / rhs
        }
        return v
    }
    private fun parseFactor(): Double {
        if (peek() == '-') { pos++; return -parseFactor() }
        if (peek() == '(') {
            pos++
            val v = parseExpr()
            if (peek() == ')') pos++
            return v
        }
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        return s.substring(start, pos).toDouble()
    }
}
