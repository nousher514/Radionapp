package com.radion.assistant

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceEngine(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                // Slightly lower pitch + a touch slower — reads as calmer/deeper,
                // closer to a "Jarvis"-style voice than the default TTS tone.
                tts?.setPitch(0.82f)
                tts?.setSpeechRate(0.97f)
                // If the device's TTS engine exposes multiple English voices, prefer
                // one whose name suggests a male voice — not all engines label this,
                // so this is a best-effort pick, not guaranteed on every device.
                try {
                    val candidates = tts?.voices?.filter {
                        it.locale.language == "en" && !it.isNetworkConnectionRequired
                    }
                    val male = candidates?.firstOrNull { it.name.contains("male", ignoreCase = true) && !it.name.contains("female", ignoreCase = true) }
                        ?: candidates?.firstOrNull { it.name.contains("#male", ignoreCase = true) }
                    if (male != null) tts?.voice = male
                } catch (e: Exception) { /* fall back to default voice — still works, just not tuned */ }
                ttsReady = true
            }
        }
    }

    fun speak(text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}) {
        if (!ttsReady) { onDone(); return }
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { onStart() }
            override fun onDone(utteranceId: String?) { onDone() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { onDone() }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "radion_utterance")
    }

    fun stopSpeaking() { tts?.stop() }

    /** Starts one voice capture. onResult fires with the transcribed text, onFail on failure. */
    fun listenOnce(onResult: (String) -> Unit, onFail: (String) -> Unit, onStart: () -> Unit = {}, onEnd: () -> Unit = {}) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onFail("Speech recognition not available on this device.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { onStart() }
            override fun onResults(results: android.os.Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val said = matches?.firstOrNull()
                if (said != null) onResult(said) else onFail("Didn't catch that.")
                onEnd()
            }
            override fun onError(error: Int) { onFail("Mic error ($error)"); onEnd() }
            override fun onEndOfSpeech() {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        recognizer?.startListening(intent)
    }

    fun destroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
