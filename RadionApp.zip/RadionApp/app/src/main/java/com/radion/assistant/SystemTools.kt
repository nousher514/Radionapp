package com.radion.assistant

import android.app.AlarmManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import java.util.TimeZone

/**
 * These functions touch the real phone — actual calendar, actual contacts, actual dialer.
 * This is the whole reason a native app exists instead of the web version: none of this
 * is reachable from a browser, on any phone, ever.
 */
class SystemTools(private val context: Context) {

    /** Reads real upcoming events from the device's calendar (requires READ_CALENDAR). */
    fun getUpcomingEvents(limit: Int = 5): List<String> {
        val results = mutableListOf<String>()
        val projection = arrayOf(
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART
        )
        val now = System.currentTimeMillis()
        val cursor = context.contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            "${CalendarContract.Events.DTSTART} >= ?",
            arrayOf(now.toString()),
            "${CalendarContract.Events.DTSTART} ASC"
        )
        cursor?.use {
            val titleIdx = it.getColumnIndex(CalendarContract.Events.TITLE)
            val startIdx = it.getColumnIndex(CalendarContract.Events.DTSTART)
            while (it.moveToNext() && results.size < limit) {
                val title = it.getString(titleIdx) ?: "Untitled event"
                val start = it.getLong(startIdx)
                results.add("$title @ ${java.text.DateFormat.getDateTimeInstance().format(start)}")
            }
        }
        return results
    }

    /** Creates a real event on the device's default calendar (requires WRITE_CALENDAR). */
    fun createEvent(title: String, startMillis: Long, durationMinutes: Int = 60): Boolean {
        val values = ContentValues().apply {
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DTSTART, startMillis)
            put(CalendarContract.Events.DTEND, startMillis + durationMinutes * 60_000L)
            put(CalendarContract.Events.CALENDAR_ID, 1)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        return uri != null
    }

    /** Looks up a real contact by name (requires READ_CONTACTS). */
    fun findContactNumber(name: String): String? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val cursor = context.contentResolver.query(uri, projection, selection, arrayOf("%$name%"), null)
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numberIdx)
            }
        }
        return null
    }

    /** Places a real phone call (requires CALL_PHONE). */
    fun callNumber(number: String) {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /** Sets a real system alarm via the device's built-in Clock app. */
    fun setSystemAlarm(hour: Int, minute: Int, label: String) {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
