package com.radion.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BG = Color(0xFF070D0C)
private val PANEL = Color(0xFF10201C)
private val LINE = Color(0xFF1D332E)
private val TEXT = Color(0xFFDCECE5)
private val DIM = Color(0xFF5C7A72)
private val GREEN = Color(0xFF1FAE6E)
private val BLUE = Color(0xFF3F5FE0)

class MainActivity : ComponentActivity() {
    private lateinit var permissions: PermissionsManager
    private lateinit var systemTools: SystemTools

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissions = PermissionsManager(this)
        systemTools = SystemTools(this)

        setContent {
            RadionScreen(permissions = permissions, systemTools = systemTools)
        }
    }
}

@Composable
fun RadionScreen(permissions: PermissionsManager, systemTools: SystemTools) {
    var log by remember { mutableStateOf(listOf("RADION — native core online.")) }
    var calendarGranted by remember { mutableStateOf(permissions.has(PermissionsManager.CALENDAR_READ)) }
    var contactsGranted by remember { mutableStateOf(permissions.has(PermissionsManager.CONTACTS)) }
    var callGranted by remember { mutableStateOf(permissions.has(PermissionsManager.CALL_PHONE)) }
    var micGranted by remember { mutableStateOf(permissions.has(PermissionsManager.MIC)) }

    fun addLog(line: String) { log = log + line }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BG)
            .padding(20.dp)
    ) {
        Text("RADION", color = TEXT, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("NATIVE CORE / SYSTEM ACCESS", color = DIM, fontSize = 11.sp)
        Spacer(Modifier.height(20.dp))

        // ---- Real permission toggles — each triggers an actual Android system prompt ----
        PermissionRow("Microphone", micGranted) {
            permissions.request(PermissionsManager.MIC) { granted ->
                micGranted = granted
                addLog(if (granted) "Microphone access granted." else "Microphone access denied.")
            }
        }
        PermissionRow("Calendar", calendarGranted) {
            permissions.requestAll(
                arrayOf(PermissionsManager.CALENDAR_READ, PermissionsManager.CALENDAR_WRITE)
            ) { granted ->
                calendarGranted = granted
                addLog(if (granted) "Calendar access granted." else "Calendar access denied.")
            }
        }
        PermissionRow("Contacts", contactsGranted) {
            permissions.request(PermissionsManager.CONTACTS) { granted ->
                contactsGranted = granted
                addLog(if (granted) "Contacts access granted." else "Contacts access denied.")
            }
        }
        PermissionRow("Phone calls", callGranted) {
            permissions.request(PermissionsManager.CALL_PHONE) { granted ->
                callGranted = granted
                addLog(if (granted) "Call permission granted." else "Call permission denied.")
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- Real actions, only enabled once the matching permission is actually granted ----
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionButton("Read calendar", enabled = calendarGranted) {
                val events = systemTools.getUpcomingEvents()
                if (events.isEmpty()) addLog("No upcoming events found.")
                else events.forEach { addLog(it) }
            }
            ActionButton("Set clock alarm", enabled = true) {
                systemTools.setSystemAlarm(7, 30, "Radion alarm")
                addLog("Opened system clock to confirm a 7:30 alarm.")
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("ACTIVITY LOG", color = DIM, fontSize = 10.sp)
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(PANEL)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(log) { line ->
                Text(line, color = TEXT, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun PermissionRow(label: String, granted: Boolean, onRequest: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TEXT, fontSize = 14.sp)
        Button(
            onClick = onRequest,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (granted) GREEN else PANEL,
                contentColor = if (granted) BG else TEXT
            )
        ) {
            Text(if (granted) "Granted" else "Request access")
        }
    }
}

@Composable
fun ActionButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = BLUE)
    ) {
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}
