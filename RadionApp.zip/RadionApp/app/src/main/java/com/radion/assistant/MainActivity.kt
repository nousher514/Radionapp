@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.radion.assistant

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URLEncoder

private val BG = Color(0xFF070D0C)
private val PANEL = Color(0xFF10201C)
private val PANEL2 = Color(0xFF141B25)
private val LINE = Color(0xFF1D332E)
private val TEXT = Color(0xFFDCECE5)
private val DIM = Color(0xFF5C7A72)
private val GREEN = Color(0xFF1FAE6E)
private val BLUE = Color(0xFF3F5FE0)

data class ChatMessage(val role: String, val text: String, val holoObject: String? = null)

class MainActivity : ComponentActivity() {
    private lateinit var permissions: PermissionsManager
    private lateinit var systemTools: SystemTools
    private lateinit var voiceEngine: VoiceEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissions = PermissionsManager(this)
        systemTools = SystemTools(this)
        voiceEngine = VoiceEngine(this)

        setContent {
            RadionApp(permissions = permissions, systemTools = systemTools, voiceEngine = voiceEngine)
        }
    }

    override fun onDestroy() {
        voiceEngine.destroy()
        super.onDestroy()
    }
}

// "hologram" is a hard trigger word — mirrors the web version's deterministic detection.
private fun detectHologramSubject(text: String): String? {
    val patterns = listOf(
        Regex("""hologram(?:s)?\s+of\s+(?:a |an |the )?(.+)""", RegexOption.IGNORE_CASE),
        Regex("""(?:make|show|create|build|project)\s+(?:me\s+)?a\s+hologram\s+of\s+(?:a |an |the )?(.+)""", RegexOption.IGNORE_CASE)
    )
    for (p in patterns) {
        val m = p.find(text)
        if (m != null) return m.groupValues[1].trim().trimEnd('.', '?', '!')
    }
    return if (Regex("""\bhologram(s)?\b""", RegexOption.IGNORE_CASE).containsMatchIn(text)) "object" else null
}

@Composable
fun RadionApp(permissions: PermissionsManager, systemTools: SystemTools, voiceEngine: VoiceEngine) {
    var tab by remember { mutableStateOf(0) } // 0 = Chat, 1 = System

    Column(modifier = Modifier.fillMaxSize().background(BG)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("RADION", color = TEXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("NATIVE CORE", color = DIM, fontSize = 10.sp)
            }
            Row {
                TabChip("Chat", tab == 0) { tab = 0 }
                Spacer(Modifier.width(8.dp))
                TabChip("System", tab == 1) { tab = 1 }
            }
        }
        HorizontalDivider(color = LINE)

        if (tab == 0) ChatScreen(permissions, systemTools, voiceEngine)
        else RadionSystemScreen(permissions, systemTools)
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) BLUE else PANEL2, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(label, color = if (selected) Color.White else DIM, fontSize = 12.sp)
    }
}

@Composable
fun ChatScreen(permissions: PermissionsManager, systemTools: SystemTools, voiceEngine: VoiceEngine) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val apiHistory = remember { mutableListOf<JSONObject>() }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val coreState = when {
        listening -> "listening"
        busy -> "thinking"
        speaking -> "speaking"
        else -> "idle"
    }

    fun scrollToEnd() {
        scope.launch { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
    }

    fun speakReply(text: String) {
        voiceEngine.speak(text, onStart = { speaking = true }, onDone = { speaking = false })
    }

    fun handleSend(text: String) {
        if (text.isBlank() || busy) return
        messages.add(ChatMessage("user", text))
        scrollToEnd()

        val holoSubject = detectHologramSubject(text)
        if (holoSubject != null) {
            val reply = "Projecting a wireframe blueprint of the $holoSubject."
            apiHistory.add(JSONObject().put("role", "user").put("content", text))
            apiHistory.add(JSONObject().put("role", "assistant").put("content", reply))
            messages.add(ChatMessage("assistant", reply, holoObject = holoSubject))
            speakReply(reply)
            scrollToEnd()
            return
        }

        busy = true
        apiHistory.add(JSONObject().put("role", "user").put("content", text))
        AssistantBrain.send(apiHistory, systemTools, AssistantBrain.getApiKey(context), mainHandler, object : AssistantBrain.Callback {
            override fun onResult(text: String) {
                busy = false
                val reply = text.ifBlank { "I don't have a response for that." }
                messages.add(ChatMessage("assistant", reply))
                speakReply(reply)
                scrollToEnd()
            }
            override fun onError(message: String) {
                busy = false
                messages.add(ChatMessage("assistant", "I hit an issue: $message"))
                scrollToEnd()
            }
        })
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        StatusPill(coreState)
        Spacer(Modifier.height(4.dp))

        if (messages.isEmpty()) {
            CoreVisualizer(coreState, modifier = Modifier.padding(vertical = 12.dp))
            Text(
                "Type a request, or press the mic to speak.",
                color = DIM, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(16.dp))
            SuggestionChips { handleSend(it) }
            Spacer(Modifier.height(8.dp))
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(msg)
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth().background(PANEL, shape = MaterialTheme.shapes.medium).padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                permissions.request(PermissionsManager.MIC) { granted ->
                    if (!granted) return@request
                    listening = true
                    voiceEngine.listenOnce(
                        onResult = { said -> listening = false; input = ""; handleSend(said) },
                        onFail = { listening = false },
                        onStart = { listening = true },
                        onEnd = { listening = false }
                    )
                }
            }) {
                Icon(Icons.Filled.Mic, contentDescription = "Mic", tint = if (listening) BLUE else DIM)
            }
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask RADION anything…", color = DIM) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TEXT,
                    unfocusedTextColor = TEXT
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                singleLine = true
            )
            IconButton(onClick = { val t = input; input = ""; handleSend(t) }, enabled = !busy) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = GREEN)
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.role == "user"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Text(if (isUser) "YOU" else "RADION", color = if (isUser) BLUE else GREEN, fontSize = 9.sp)
        Box(
            modifier = Modifier
                .background(if (isUser) Color(0xFF12203A) else PANEL, shape = MaterialTheme.shapes.small)
                .padding(10.dp)
        ) {
            Text(msg.text, color = TEXT, fontSize = 14.sp)
        }
        if (msg.holoObject != null) {
            Spacer(Modifier.height(6.dp))
            HologramView(msg.holoObject)
        }
    }
}

@Composable
fun HologramView(objectName: String) {
    val encoded = URLEncoder.encode(objectName, "UTF-8")
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(240.dp),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                loadUrl("file:///android_asset/hologram.html?object=$encoded")
            }
        },
        update = { webView -> webView.loadUrl("file:///android_asset/hologram.html?object=$encoded") }
    )
}

@Composable
fun StatusPill(state: String) {
    val color = when (state) {
        "listening" -> BLUE
        "thinking" -> Color(0xFFE8A33D)
        "speaking" -> GREEN
        else -> DIM
    }
    Row(
        modifier = Modifier
            .background(PANEL2, shape = MaterialTheme.shapes.extraLarge)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .background(color, shape = androidx.compose.foundation.shape.CircleShape)
        )
        Spacer(Modifier.width(7.dp))
        Text(state.uppercase(), color = DIM, fontSize = 10.sp)
    }
}

@Composable
fun CoreVisualizer(state: String, modifier: Modifier = Modifier) {
    val color = when (state) {
        "listening" -> BLUE
        "thinking" -> Color(0xFFE8A33D)
        "speaking" -> GREEN
        else -> LINE
    }
    val label = when (state) {
        "listening" -> "LISTENING"
        "thinking" -> "THINKING"
        "speaking" -> "SPEAKING"
        else -> "READY"
    }
    val infiniteTransition = rememberInfiniteTransition(label = "core")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(animation = tween(1200), repeatMode = RepeatMode.Reverse),
        label = "pulse"
    )
    val scale = if (state == "idle") 1f else pulse

    Box(
        modifier = modifier.fillMaxWidth().height(180.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(170.dp)
                .graphicsLayer(scaleX = scale, scaleY = scale)
                .border(1.dp, color.copy(alpha = 0.5f), androidx.compose.foundation.shape.CircleShape)
        )
        Box(
            modifier = Modifier
                .size(130.dp)
                .border(1.dp, color.copy(alpha = 0.35f), androidx.compose.foundation.shape.CircleShape)
        )
        Box(
            modifier = Modifier
                .size(88.dp)
                .background(PANEL2, shape = androidx.compose.foundation.shape.CircleShape)
                .border(1.dp, LINE, androidx.compose.foundation.shape.CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = color, fontSize = 9.sp)
        }
    }
}

@Composable
fun SuggestionChips(onPick: (String) -> Unit) {
    val chips = listOf(
        "what time is it",
        "make a hologram of a planet",
        "note that I need to call Sam",
        "what's 340 * 12"
    )
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        chips.forEach { chip ->
            Box(
                modifier = Modifier
                    .background(PANEL2, shape = MaterialTheme.shapes.small)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    chip, color = DIM, fontSize = 10.sp,
                    modifier = Modifier.clickableSimple { onPick(chip) }
                )
            }
        }
    }
}

// small helper so we don't need to pull in the full Material ripple/indication stack
fun Modifier.clickableSimple(onClick: () -> Unit): Modifier = this.then(
    Modifier.pointerInput(Unit) {
        detectTapGestures(onTap = { onClick() })
    }
)
