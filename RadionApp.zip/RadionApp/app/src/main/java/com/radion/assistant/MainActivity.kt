package com.radion.assistant

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URLEncoder

private val BG = Color(0xFF070D0C)
private val PANEL = Color(0xFF10201C)
private val PANEL2 = Color(0xFF141B25)
private val LINE = Color(0xFF1D332E)
private val TEXT = Color(0xFFDCECE5)
private val DIM = Color(0xFF5C7A72)
private val GREEN = Color(0xFF1FAE6E)
private val BLUE = Color(0xFF3F5FE0)

data class ChatMessage(val role: String, val text: String, val holoObject: String? = null)

class MainActivity : ComponentActivity() {
    private lateinit var permissions: PermissionsManager
    private lateinit var systemTools: SystemTools
    private lateinit var voiceEngine: VoiceEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissions = PermissionsManager(this)
        systemTools = SystemTools(this)
        voiceEngine = VoiceEngine(this)

        setContent {
            RadionApp(permissions = permissions, systemTools = systemTools, voiceEngine = voiceEngine)
        }
    }

    override fun onDestroy() {
        voiceEngine.destroy()
        super.onDestroy()
    }
}

// "hologram" is a hard trigger word — mirrors the web version's deterministic detection.
private fun detectHologramSubject(text: String): String? {
    val patterns = listOf(
        Regex("""hologram(?:s)?\s+of\s+(?:a |an |the )?(.+)""", RegexOption.IGNORE_CASE),
        Regex("""(?:make|show|create|build|project)\s+(?:me\s+)?a\s+hologram\s+of\s+(?:a |an |the )?(.+)""", RegexOption.IGNORE_CASE)
    )
    for (p in patterns) {
        val m = p.find(text)
        if (m != null) return m.groupValues[1].trim().trimEnd('.', '?', '!')
    }
    return if (Regex("""\bhologram(s)?\b""", RegexOption.IGNORE_CASE).containsMatchIn(text)) "object" else null
}

@Composable
fun RadionApp(permissions: PermissionsManager, systemTools: SystemTools, voiceEngine: VoiceEngine) {
    var tab by remember { mutableStateOf(0) } // 0 = Chat, 1 = System

    Column(modifier = Modifier.fillMaxSize().background(BG)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("RADION", color = TEXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("NATIVE CORE", color = DIM, fontSize = 10.sp)
            }
            Row {
                TabChip("Chat", tab == 0) { tab = 0 }
                Spacer(Modifier.width(8.dp))
                TabChip("System", tab == 1) { tab = 1 }
            }
        }
        Divider(color = LINE)

        if (tab == 0) ChatScreen(permissions, systemTools, voiceEngine)
        else RadionSystemScreen(permissions, systemTools)
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) BLUE else PANEL2, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(label, color = if (selected) Color.White else DIM, fontSize = 12.sp)
    }
}

@Composable
fun ChatScreen(permissions: PermissionsManager, systemTools: SystemTools, voiceEngine: VoiceEngine) {
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val apiHistory = remember { mutableListOf<JSONObject>() }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    fun scrollToEnd() {
        scope.launch { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
    }

    fun handleSend(text: String) {
        if (text.isBlank() || busy) return
        messages.add(ChatMessage("user", text))
        scrollToEnd()

        val holoSubject = detectHologramSubject(text)
        if (holoSubject != null) {
            val reply = "Projecting a wireframe blueprint of the $holoSubject."
            apiHistory.add(JSONObject().put("role", "user").put("content", text))
            apiHistory.add(JSONObject().put("role", "assistant").put("content", reply))
            messages.add(ChatMessage("assistant", reply, holoObject = holoSubject))
            voiceEngine.speak(reply)
            scrollToEnd()
            return
        }

        busy = true
        apiHistory.add(JSONObject().put("role", "user").put("content", text))
        AssistantBrain.send(apiHistory, systemTools, mainHandler, object : AssistantBrain.Callback {
            override fun onResult(text: String) {
                busy = false
                val reply = text.ifBlank { "I don't have a response for that." }
                messages.add(ChatMessage("assistant", reply))
                voiceEngine.speak(reply)
                scrollToEnd()
            }
            override fun onError(message: String) {
                busy = false
                messages.add(ChatMessage("assistant", "I hit an issue: $message"))
                scrollToEnd()
            }
        })
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(msg)
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth().background(PANEL, shape = MaterialTheme.shapes.medium).padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                permissions.request(PermissionsManager.MIC) { granted ->
                    if (!granted) return@request
                    listening = true
                    voiceEngine.listenOnce(
                        onResult = { said -> listening = false; input = ""; handleSend(said) },
                        onError = { listening = false },
                        onStart = { listening = true },
                        onEnd = { listening = false }
                    )
                }
            }) {
                Icon(Icons.Filled.Mic, contentDescription = "Mic", tint = if (listening) BLUE else DIM)
            }
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask RADION anything…", color = DIM) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TEXT,
                    unfocusedTextColor = TEXT
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                singleLine = true
            )
            IconButton(onClick = { val t = input; input = ""; handleSend(t) }, enabled = !busy) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = GREEN)
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.role == "user"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Text(if (isUser) "YOU" else "RADION", color = if (isUser) BLUE else GREEN, fontSize = 9.sp)
        Box(
            modifier = Modifier
                .background(if (isUser) Color(0xFF12203A) else PANEL, shape = MaterialTheme.shapes.small)
                .padding(10.dp)
        ) {
            Text(msg.text, color = TEXT, fontSize = 14.sp)
        }
        if (msg.holoObject != null) {
            Spacer(Modifier.height(6.dp))
            HologramView(msg.holoObject)
        }
    }
}

@Composable
fun HologramView(objectName: String) {
    val encoded = URLEncoder.encode(objectName, "UTF-8")
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(240.dp),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                loadUrl("file:///android_asset/hologram.html?object=$encoded")
            }
        },
        update = { webView -> webView.loadUrl("file:///android_asset/hologram.html?object=$encoded") }
    )
}
