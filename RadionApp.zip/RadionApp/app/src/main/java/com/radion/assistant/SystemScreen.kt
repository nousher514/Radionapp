package com.radion.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BG2 = Color(0xFF070D0C)
private val PANEL3 = Color(0xFF10201C)
private val TEXT2 = Color(0xFFDCECE5)
private val DIM2 = Color(0xFF5C7A72)
private val GREEN2 = Color(0xFF1FAE6E)
private val BLUE2 = Color(0xFF3F5FE0)

@Composable
fun RadionSystemScreen(permissions: PermissionsManager, systemTools: SystemTools) {
    var log by remember { mutableStateOf(listOf("System access panel.")) }
    var calendarGranted by remember { mutableStateOf(permissions.has(PermissionsManager.CALENDAR_READ)) }
    var contactsGranted by remember { mutableStateOf(permissions.has(PermissionsManager.CONTACTS)) }
    var callGranted by remember { mutableStateOf(permissions.has(PermissionsManager.CALL_PHONE)) }
    var micGranted by remember { mutableStateOf(permissions.has(PermissionsManager.MIC)) }

    fun addLog(line: String) { log = log + line }

    Column(modifier = Modifier.fillMaxSize().background(BG2).padding(16.dp)) {
        SystemPermRow("Microphone", micGranted) {
            permissions.request(PermissionsManager.MIC) { granted ->
                micGranted = granted
                addLog(if (granted) "Microphone access granted." else "Microphone access denied.")
            }
        }
        SystemPermRow("Calendar", calendarGranted) {
            permissions.requestAll(arrayOf(PermissionsManager.CALENDAR_READ, PermissionsManager.CALENDAR_WRITE)) { granted ->
                calendarGranted = granted
                addLog(if (granted) "Calendar access granted." else "Calendar access denied.")
            }
        }
        SystemPermRow("Contacts", contactsGranted) {
            permissions.request(PermissionsManager.CONTACTS) { granted ->
                contactsGranted = granted
                addLog(if (granted) "Contacts access granted." else "Contacts access denied.")
            }
        }
        SystemPermRow("Phone calls", callGranted) {
            permissions.request(PermissionsManager.CALL_PHONE) { granted ->
                callGranted = granted
                addLog(if (granted) "Call permission granted." else "Call permission denied.")
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SystemActionButton("Read calendar", enabled = calendarGranted) {
                val events = systemTools.getUpcomingEvents()
                if (events.isEmpty()) addLog("No upcoming events found.") else events.forEach { addLog(it) }
            }
            SystemActionButton("Set clock alarm", enabled = true) {
                systemTools.setSystemAlarm(7, 30, "Radion alarm")
                addLog("Opened system clock to confirm a 7:30 alarm.")
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("ACTIVITY LOG", color = DIM2, fontSize = 10.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f).background(PANEL3).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(log) { line -> Text(line, color = TEXT2, fontSize = 13.sp) }
        }
    }
}

@Composable
fun SystemPermRow(label: String, granted: Boolean, onRequest: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TEXT2, fontSize = 14.sp)
        Button(
            onClick = onRequest,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (granted) GREEN2 else PANEL3,
                contentColor = if (granted) BG2 else TEXT2
            )
        ) { Text(if (granted) "Granted" else "Request access") }
    }
}

@Composable
fun SystemActionButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, colors = ButtonDefaults.buttonColors(containerColor = BLUE2)) {
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}
