package com.radion.assistant

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Wraps Android's real runtime permission system. Each capability Radion offers
 * (calendar, contacts, calls, alarms) is gated behind an actual system permission
 * prompt the user must approve — nothing here bypasses that.
 */
class PermissionsManager(private val activity: ComponentActivity) {

    private var onResult: ((granted: Boolean) -> Unit)? = null

    private val launcher = activity.registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> onResult?.invoke(granted) }

    private val multiLauncher = activity.registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results -> onResult?.invoke(results.values.all { it }) }

    fun has(permission: String): Boolean =
        ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED

    fun request(permission: String, callback: (Boolean) -> Unit) {
        if (has(permission)) { callback(true); return }
        onResult = callback
        launcher.launch(permission)
    }

    fun requestAll(permissions: Array<String>, callback: (Boolean) -> Unit) {
        val missing = permissions.filter { !has(it) }
        if (missing.isEmpty()) { callback(true); return }
        onResult = callback
        multiLauncher.launch(missing.toTypedArray())
    }

    companion object {
        const val MIC = Manifest.permission.RECORD_AUDIO
        const val CALENDAR_READ = Manifest.permission.READ_CALENDAR
        const val CALENDAR_WRITE = Manifest.permission.WRITE_CALENDAR
        const val CONTACTS = Manifest.permission.READ_CONTACTS
        const val CALL_PHONE = Manifest.permission.CALL_PHONE
        const val SMS = Manifest.permission.SEND_SMS
        const val NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
    }
}
